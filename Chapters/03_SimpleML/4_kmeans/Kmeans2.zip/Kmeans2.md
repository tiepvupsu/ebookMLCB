
## MNIST

Download:



```python
# %reset
import numpy as np 
from mnist import MNIST
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import normalize
```

[display_network.py](https://github.com/tiepvupsu/tiepvupsu.github.io/blob/master/assets/kmeans/display_network.py)


```python
from display_network import *

mndata = MNIST('../MNIST/')
mndata.load_testing()
X = mndata.test_images
# X0 = np.asarray(X)[:1000,:]/256.0
X = X0
# X = normalize(X0)
# X = np.sum(np.abs(X)**2,axis=-1)**(1./2)

K = 10
if is_train_set:
	kmeans = MiniBatchKMeans(n_clusters=K, n_init=30, batch_size=10000).fit(X)
else:
	# kmeans = MiniBatchKMeans(n_clusters=K, init='k-means++', n_init=10, batch_size=1000, verbose = True).fit(X)
	kmeans = KMeans(n_clusters=K).fit(X)

pred_label = kmeans.predict(X)
```


```python

A = display_network(kmeans.cluster_centers_.T, K, 1)

f1 = plt.imshow(A, interpolation='nearest', cmap = "jet")
f1.axes.get_xaxis().set_visible(False)
f1.axes.get_yaxis().set_visible(False)
plt.show()
# plt.savefig('a1.png', bbox_inches='tight')


# a colormap and a normalization instance
# cmap = plt.cm.jet
# norm = plt.Normalize(vmin=A.min(), vmax=A.max())

# # map the normalized data to colors
# # image is now RGBA (512x512x4) 
# image = cmap(norm(A))

# import scipy.misc
# scipy.misc.imsave('aa.png', image)
```


![png](output_4_0.png)


Chọn một vài ảnh từ mỗi cluster.


```python
N0 = 20;
X1 = np.zeros((N0*K, 784))
X2 = np.zeros((N0*K, 784))

for k in range(K):
    Xk = X0[pred_label == k, :]

    center_k = [kmeans.cluster_centers_[k]]
    neigh = NearestNeighbors(N0).fit(Xk)
    dist, nearest_id  = neigh.kneighbors(center_k, N0)
    
    X1[N0*k: N0*k + N0,:] = Xk[nearest_id, :]
    X2[N0*k: N0*k + N0,:] = Xk[:N0, :]
```


```python
plt.axis('off')
A = display_network(X2.T, K, N0)
f2 = plt.imshow(A, interpolation='nearest' )
plt.gray()
plt.show()

# import scipy.misc
# scipy.misc.imsave('bb.png', A)


# plt.axis('off')
# A = display_network(X1.T, 10, N0)
# scipy.misc.imsave('cc.png', A)
# f2 = plt.imshow(A, interpolation='nearest' )
# plt.gray()

# plt.show()
```


![png](output_7_0.png)


Segmentation and Compression


```python
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans

img = mpimg.imread('insect.jpg')
plt.imshow(img)
imgplot = plt.imshow(img)
plt.axis('off')
plt.show() 
```


![png](output_9_0.png)



```python
X = img.reshape((img.shape[0]*img.shape[1], img.shape[2]))
```


```python
K = 5

kmeans = KMeans(n_clusters=K).fit(X)
label = kmeans.predict(X)

img_seg = label.reshape((img.shape[0], img.shape[1]))

plt.imshow(img_seg, interpolation='nearest', cmap = "jet")
plt.axis('off')
plt.show()
```


![png](output_11_0.png)


test numpy



```python
K = 5

for K in [5, 10, 15, 20]:
    kmeans = KMeans(n_clusters=K).fit(X)
    label = kmeans.predict(X)

    img4 = np.zeros_like(X)
    # replace each pixel by its center
    for k in range(K):
        img4[label == k] = kmeans.cluster_centers_[k]
    # reshape and display output image
    img5 = img4.reshape((img.shape[0], img.shape[1], img.shape[2]))
    plt.imshow(img5, interpolation='nearest')
    plt.axis('off')
    plt.show()
```


![png](output_13_0.png)



![png](output_13_1.png)



![png](output_13_2.png)



![png](output_13_3.png)

